# -*- coding: utf-8 -*-
"""
Created on Fri Jul 20 11:38:24 2018

@author: microled

Conversión de unidades de longitud
Escriba un programa que convierta de centímetros a pulgadas. 
Una pulgada es igual a 2.54 centímetros
"""

print("##################################")
print("# Convertir unidades de longitud #")
print("#   de centimetros a pulgadas    #")
print("##################################")
      
cent=int(input("Introducir centimetros: "))

print("%d centímetros son %f pulgadas"%(cent,cent/2.54))


      
