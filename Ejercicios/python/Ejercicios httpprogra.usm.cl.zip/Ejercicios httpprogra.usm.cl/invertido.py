# -*- coding: utf-8 -*-
"""
Created on Fri Jul 20 11:38:24 2018

@author: microled

Número invertido
Escriba un programa que pida al usuario un entero de tres dígitos, y 
entregue el número con los dígitos en orden inverso:
"""

print("##################################")
print("#        Invertir número   #      ")
print("##################################")
      
num=(input("Introducir número: "))

print("el número %s invertido es: %s"%(num,num[::-1]))

      
