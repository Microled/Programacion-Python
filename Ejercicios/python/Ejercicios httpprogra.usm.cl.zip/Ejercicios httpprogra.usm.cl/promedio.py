# -*- coding: utf-8 -*-
"""
Created on Fri Jul 20 11:20:20 2018

@author: microled
Círculos¶
Promedio
Escriba un programa que calcule el promedio de 4 notas ingresadas 
por el usuario:
"""

print("################################")
print("#     Promedio de 4 notas      #")
print("################################")

nota1=int(input("Introduce la nota 1: "))
nota2=int(input("Introduce la nota 2: "))
nota3=int(input("Introduce la nota 3: "))
nota4=int(input("Introduce la nota 4: "))

promedio=(nota1+nota2+nota3+nota4)/4
print ("Promedio: ",promedio)