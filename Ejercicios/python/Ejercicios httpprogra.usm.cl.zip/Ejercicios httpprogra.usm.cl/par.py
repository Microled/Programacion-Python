# -*- coding: utf-8 -*-
"""
Created on Fri Jul 20 11:38:24 2018

@author: microled

Determinar par
Escriba un programa que determine si el número entero 
ingresado por el usuario es par o no
"""

print("##################################")
print("#          Es Par??              #")
print("##################################")
numero=int(input("Introducir un número: "))
if numero%2==0:
    print("El número %d es par"%numero)
else:
    print("El número %d no es par"%numero)



      
